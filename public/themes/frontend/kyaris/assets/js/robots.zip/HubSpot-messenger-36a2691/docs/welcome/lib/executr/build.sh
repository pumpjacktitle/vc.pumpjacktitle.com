cp src/css/* build/css

coffee -o build/js src/coffee

